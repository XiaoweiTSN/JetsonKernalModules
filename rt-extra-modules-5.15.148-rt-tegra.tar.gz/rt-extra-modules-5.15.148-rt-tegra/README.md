# RT 增量内核模块归档

本目录保存本次为 `5.15.148-rt-tegra` 增量开启并安装后的树内内核模块。

这些模块来自：

```text
/home/tnca/neardi_r36.4/jetpack_6.2.1/Linux_for_Tegra/rootfs/lib/modules/5.15.148-rt-tegra/kernel/
```

本归档按 rootfs 相对路径保存：

```text
rootfs/lib/modules/5.15.148-rt-tegra/kernel/...
```

注意：这些是内核源码树内模块，应放在 `/lib/modules/5.15.148-rt-tegra/kernel/` 下，不是 OOT 模块，不应放到 `/lib/modules/5.15.148-rt-tegra/updates/`。

## 模块列表和目标位置

| 模块 | 目标位置 |
|---|---|
| `hid-sensor-hub.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/hid/hid-sensor-hub.ko` |
| `hid-sensor-accel-3d.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/iio/accel/hid-sensor-accel-3d.ko` |
| `hid-sensor-iio-common.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/iio/common/hid-sensors/hid-sensor-iio-common.ko` |
| `hid-sensor-trigger.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/iio/common/hid-sensors/hid-sensor-trigger.ko` |
| `hid-sensor-gyro-3d.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/iio/gyro/hid-sensor-gyro-3d.ko` |
| `m_can.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/can/m_can/m_can.ko` |
| `slcan.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/can/slcan.ko` |
| `kvaser_usb.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/can/usb/kvaser_usb/kvaser_usb.ko` |
| `peak_usb.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/can/usb/peak_usb/peak_usb.ko` |
| `usb_8dev.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/can/usb/usb_8dev.ko` |
| `qmi_wwan.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/usb/qmi_wwan.ko` |
| `ath10k_usb.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/wireless/ath/ath10k/ath10k_usb.ko` |
| `mt7601u.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/wireless/mediatek/mt7601u/mt7601u.ko` |
| `rtl8xxxu.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/wireless/realtek/rtl8xxxu/rtl8xxxu.ko` |
| `rtl8192c-common.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/wireless/realtek/rtlwifi/rtl8192c/rtl8192c-common.ko` |
| `rtl8192cu.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/wireless/realtek/rtlwifi/rtl8192cu/rtl8192cu.ko` |
| `rtl_usb.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/wireless/realtek/rtlwifi/rtl_usb.ko` |
| `rtlwifi.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/wireless/realtek/rtlwifi/rtlwifi.ko` |
| `wwan.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/net/wwan/wwan.ko` |
| `cdc-wdm.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/usb/class/cdc-wdm.ko` |
| `pl2303.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/usb/serial/pl2303.ko` |
| `uas.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/drivers/usb/storage/uas.ko` |
| `snd-soc-tegra210-admaif.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/sound/soc/tegra/snd-soc-tegra210-admaif.ko` |
| `snd-soc-tegra210-adx.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/sound/soc/tegra/snd-soc-tegra210-adx.ko` |
| `snd-soc-tegra210-ahub.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/sound/soc/tegra/snd-soc-tegra210-ahub.ko` |
| `snd-soc-tegra210-amx.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/sound/soc/tegra/snd-soc-tegra210-amx.ko` |
| `snd-soc-tegra210-dmic.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/sound/soc/tegra/snd-soc-tegra210-dmic.ko` |
| `snd-soc-tegra210-i2s.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/sound/soc/tegra/snd-soc-tegra210-i2s.ko` |
| `snd-soc-tegra210-mixer.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/sound/soc/tegra/snd-soc-tegra210-mixer.ko` |
| `snd-soc-tegra210-mvc.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/sound/soc/tegra/snd-soc-tegra210-mvc.ko` |
| `snd-soc-tegra210-ope.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/sound/soc/tegra/snd-soc-tegra210-ope.ko` |
| `snd-soc-tegra210-sfc.ko` | `/lib/modules/5.15.148-rt-tegra/kernel/sound/soc/tegra/snd-soc-tegra210-sfc.ko` |

## 复制到待刷机 rootfs

在编译主机上，如果要把本目录中的模块重新放回当前 L4T rootfs，可在本目录的上一级执行：

```bash
sudo cp -a rt_incremental_modules_5.15.148-rt-tegra_20260709/rootfs/lib/modules/5.15.148-rt-tegra/kernel/. \
  /home/tnca/neardi_r36.4/jetpack_6.2.1/Linux_for_Tegra/rootfs/lib/modules/5.15.148-rt-tegra/kernel/
```

复制后重新生成模块依赖，并按刷机教程更新 L4T initrd：

```bash
cd /home/tnca/neardi_r36.4/jetpack_6.2.1/Linux_for_Tegra
sudo depmod -b rootfs -a 5.15.148-rt-tegra
sudo ./tools/l4t_update_initrd.sh --ldk_dir "$PWD"
```

## 复制到已启动的目标机

如果目标机已经运行 `5.15.148-rt-tegra`，可以把 `rootfs/lib/modules/5.15.148-rt-tegra/kernel/` 下的内容合并到目标机：

```bash
scp -r rt_incremental_modules_5.15.148-rt-tegra_20260709/rootfs/lib/modules/5.15.148-rt-tegra/kernel/* \
  root@192.168.55.1:/lib/modules/5.15.148-rt-tegra/kernel/
ssh root@192.168.55.1 'depmod -a 5.15.148-rt-tegra'
```

如果这些模块需要进入 early boot 阶段，还需要在目标机上按 NVIDIA/Jetson 的方式更新 initrd。普通 USB/CAN/WiFi/HID/声卡外设模块通常不属于根文件系统挂载前的必需模块。

## 验证

本次归档共复制 32 个 `.ko`。归档后检查到所有模块 vermagic 一致：

```text
5.15.148-rt-tegra SMP preempt_rt mod_unload modversions aarch64
```
