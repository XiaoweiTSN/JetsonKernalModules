#!/bin/bash

# Jetson Orin Kernel Module Installation Script
# Supports: 5.15.148-tegra / 5.15.185(-tegra)
# Modules:  RealSense camera support, gs_usb (CAN), ch341 (USB serial)

set -euo pipefail

# ── Color output helpers ──────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
err()   { echo -e "${RED}[ERROR]${NC} $*"; }

# ── Root check ────────────────────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
    err "This script must be run as root (sudo)"
    exit 1
fi

# ── Detect kernel version ────────────────────────────────────────────
KERNEL_VER=$(uname -r)
info "Detected kernel version: ${KERNEL_VER}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Map kernel version to module directory
case "$KERNEL_VER" in
    5.15.148*)
        MODULE_SRC_DIR="${SCRIPT_DIR}/5.15.148-tegra"
        ;;
    5.15.185*)
        MODULE_SRC_DIR="${SCRIPT_DIR}/5.15.185"
        ;;
    *)
        err "Unsupported kernel version: ${KERNEL_VER}"
        err "This package supports: 5.15.148-tegra, 5.15.185(-tegra)"
        exit 1
        ;;
esac

if [ ! -d "$MODULE_SRC_DIR" ]; then
    err "Module directory not found: ${MODULE_SRC_DIR}"
    exit 1
fi

info "Using modules from: ${MODULE_SRC_DIR}"

# ── Target base directory ────────────────────────────────────────────
BASE_DIR="/lib/modules/${KERNEL_VER}/kernel"

# ── Module definitions ───────────────────────────────────────────────
# Format: "filename:module_name:target_subdir"

# RealSense camera modules
REALSENSE_MODULES=(
    "uvcvideo.ko:uvcvideo:drivers/media/usb/uvc"
    "hid-sensor-accel-3d.ko:hid_sensor_accel_3d:drivers/iio/accel"
    "hid-sensor-gyro-3d.ko:hid_sensor_gyro_3d:drivers/iio/gyro"
    "hid-sensor-iio-common.ko:hid_sensor_iio_common:drivers/iio/common/hid-sensors"
    "hid-sensor-hub.ko:hid_sensor_hub:drivers/hid"
    "hid-sensor-trigger.ko:hid_sensor_trigger:drivers/iio/common/hid-sensors"
)

# USB-CAN module (Piper robotic arm)
CAN_MODULES=(
    "gs_usb.ko:gs_usb:drivers/net/can/usb"
)

# USB serial driver (ch341 is missing from stock JetPack kernel)
SERIAL_MODULES=(
    "ch341.ko:ch341:drivers/usb/serial"
)

ALL_MODULES=("${REALSENSE_MODULES[@]}" "${CAN_MODULES[@]}" "${SERIAL_MODULES[@]}")

# ── Verify source files ─────────────────────────────────────────────
info "Checking module files..."
MISSING=0
for entry in "${ALL_MODULES[@]}"; do
    file="${entry%%:*}"
    if [ ! -f "${MODULE_SRC_DIR}/${file}" ]; then
        err "Missing: ${file}"
        MISSING=$((MISSING + 1))
    fi
done

if [ "$MISSING" -gt 0 ]; then
    err "${MISSING} module file(s) missing, aborting."
    exit 1
fi
ok "All ${#ALL_MODULES[@]} module files found."

# ── Install modules ─────────────────────────────────────────────────
info "Installing kernel modules to ${BASE_DIR} ..."
INSTALLED=0
for entry in "${ALL_MODULES[@]}"; do
    file="${entry%%:*}"
    rest="${entry#*:}"
    target_subdir="${rest#*:}"

    target_dir="${BASE_DIR}/${target_subdir}"
    mkdir -p "$target_dir"
    cp "${MODULE_SRC_DIR}/${file}" "${target_dir}/${file}"
    INSTALLED=$((INSTALLED + 1))
done
ok "Installed ${INSTALLED} modules."

# ── Update module dependencies ───────────────────────────────────────
info "Updating module dependencies (depmod)..."
depmod -a "${KERNEL_VER}"
ok "Module dependencies updated."

# ── Load modules ─────────────────────────────────────────────────────
info "Loading kernel modules..."

LOAD_ORDER=(
    # RealSense (order matters: common/hub first, then sensors, then uvc)
    "hid_sensor_iio_common"
    "hid_sensor_hub"
    "hid_sensor_trigger"
    "hid_sensor_accel_3d"
    "hid_sensor_gyro_3d"
    "uvcvideo"
    # CAN
    "gs_usb"
    # Serial
    "ch341"
)

LOAD_OK=0
LOAD_FAIL=0
for module in "${LOAD_ORDER[@]}"; do
    modprobe -r "$module" 2>/dev/null || true
    if modprobe "$module" 2>/dev/null; then
        ok "  Loaded: ${module}"
        LOAD_OK=$((LOAD_OK + 1))
    else
        warn "  Failed to load: ${module} (may need reboot)"
        LOAD_FAIL=$((LOAD_FAIL + 1))
    fi
done

# ── Summary ──────────────────────────────────────────────────────────
echo ""
echo "============================================"
echo -e "${GREEN}  Installation complete!${NC}"
echo "============================================"
echo "  Kernel:           ${KERNEL_VER}"
echo "  Modules installed: ${INSTALLED}"
echo "  Modules loaded:    ${LOAD_OK} / $((LOAD_OK + LOAD_FAIL))"
if [ "$LOAD_FAIL" -gt 0 ]; then
    echo ""
    warn "Some modules failed to load. Please reboot and verify:"
    echo "    sudo reboot"
fi
echo ""
echo "  Verify with:"
echo "    lsmod | grep -E 'uvcvideo|hid_sensor|gs_usb|ch341'"
echo "============================================"
