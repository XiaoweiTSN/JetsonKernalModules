#!/bin/bash

# Jetson Orin Kernel Module Installation Script
# Supports: 5.15.148-tegra / 5.15.148-rt-tegra / 5.15.185(-tegra)
# Modules:  RealSense/HID sensor support, gs_usb (CAN), ch341 (USB serial)

set -euo pipefail

# ── Color output helpers ──────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
err()   { echo -e "${RED}[ERROR]${NC} $*"; }

# ── Root check ────────────────────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
    err "This script must be run as root (sudo)"
    exit 1
fi

# ── Detect kernel version ─────────────────────────────────────────────
KERNEL_VER=$(uname -r)
info "Detected kernel version: ${KERNEL_VER}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ── Module definitions ────────────────────────────────────────────────
# Format: "filename:module_name:target_subdir"

# HID sensor modules used by RealSense IMU and other HID sensor devices.
HID_SENSOR_MODULES=(
    "hid-sensor-accel-3d.ko:hid_sensor_accel_3d:drivers/iio/accel"
    "hid-sensor-gyro-3d.ko:hid_sensor_gyro_3d:drivers/iio/gyro"
    "hid-sensor-iio-common.ko:hid_sensor_iio_common:drivers/iio/common/hid-sensors"
    "hid-sensor-hub.ko:hid_sensor_hub:drivers/hid"
    "hid-sensor-trigger.ko:hid_sensor_trigger:drivers/iio/common/hid-sensors"
)

# RealSense UVC module.
UVC_MODULES=(
    "uvcvideo.ko:uvcvideo:drivers/media/usb/uvc"
)

# USB-CAN module (Piper robotic arm)
CAN_MODULES=(
    "gs_usb.ko:gs_usb:drivers/net/can/usb"
)

# USB serial driver (ch341 is missing from stock JetPack kernel)
SERIAL_MODULES=(
    "ch341.ko:ch341:drivers/usb/serial"
)

FULL_MODULES=("${UVC_MODULES[@]}" "${HID_SENSOR_MODULES[@]}" "${CAN_MODULES[@]}" "${SERIAL_MODULES[@]}")
RT_MODULES=("${UVC_MODULES[@]}" "${HID_SENSOR_MODULES[@]}" "${CAN_MODULES[@]}" "${SERIAL_MODULES[@]}")

module_src_dir() {
    case "$1" in
        5.15.148-tegra)
            echo "${SCRIPT_DIR}/5.15.148-tegra"
            ;;
        5.15.148-rt-tegra)
            echo "${SCRIPT_DIR}/5.15.148-rt-tegra"
            ;;
        5.15.185*)
            echo "${SCRIPT_DIR}/5.15.185"
            ;;
        *)
            return 1
            ;;
    esac
}

select_modules_for_kernel() {
    case "$1" in
        5.15.148-rt-tegra)
            SELECTED_MODULES=("${RT_MODULES[@]}")
            ;;
        *)
            SELECTED_MODULES=("${FULL_MODULES[@]}")
            ;;
    esac
}

check_module_vermagic() {
    local target="$1"
    local module_path="$2"
    local module_vermagic
    local module_kernel

    if ! module_vermagic="$(modinfo -F vermagic "$module_path" 2>/dev/null)"; then
        err "Cannot read vermagic: ${module_path}"
        return 1
    fi

    module_kernel="${module_vermagic%% *}"
    if [ "$module_kernel" = "$target" ]; then
        return 0
    fi

    case "${target}:${module_kernel}" in
        5.15.185*:5.15.185)
            return 0
            ;;
    esac

    err "Vermagic mismatch for ${module_path}"
    err "  expected: ${target}"
    err "  actual:   ${module_vermagic}"
    return 1
}

select_load_order_for_kernel() {
    case "$1" in
        5.15.148-rt-tegra)
            LOAD_ORDER=(
                "hid_sensor_iio_common"
                "hid_sensor_hub"
                "hid_sensor_trigger"
                "hid_sensor_accel_3d"
                "hid_sensor_gyro_3d"
                "uvcvideo"
                "gs_usb"
                "ch341"
            )
            ;;
        *)
            LOAD_ORDER=(
                "hid_sensor_iio_common"
                "hid_sensor_hub"
                "hid_sensor_trigger"
                "hid_sensor_accel_3d"
                "hid_sensor_gyro_3d"
                "uvcvideo"
                "gs_usb"
                "ch341"
            )
            ;;
    esac
}

add_target_kernel() {
    local target="$1"
    local src_dir

    if ! src_dir="$(module_src_dir "$target")"; then
        return 0
    fi

    if [ ! -d "/lib/modules/${target}" ]; then
        return 0
    fi

    for existing in "${TARGET_KERNELS[@]}"; do
        if [ "$existing" = "$target" ]; then
            return 0
        fi
    done

    TARGET_KERNELS+=("$target")
}

# ── Select target kernels ─────────────────────────────────────────────
TARGET_KERNELS=()

case "$KERNEL_VER" in
    5.15.148-tegra|5.15.148-rt-tegra)
        # Some systems may keep both normal and RT kernels installed.
        add_target_kernel "5.15.148-tegra"
        add_target_kernel "5.15.148-rt-tegra"
        ;;
    5.15.185*)
        add_target_kernel "$KERNEL_VER"
        ;;
    *)
        err "Unsupported running kernel version: ${KERNEL_VER}"
        err "This package supports: 5.15.148-tegra, 5.15.148-rt-tegra, 5.15.185(-tegra)"
        exit 1
        ;;
esac

if [ "${#TARGET_KERNELS[@]}" -eq 0 ]; then
    err "No supported /lib/modules directory found for this system."
    exit 1
fi

info "Target kernel module trees:"
for target in "${TARGET_KERNELS[@]}"; do
    src_dir="$(module_src_dir "$target")"
    info "  ${target} <- ${src_dir}"
done

# ── Verify source files ─────────────────────────────────────────────
info "Checking module files..."
MISSING=0
for target in "${TARGET_KERNELS[@]}"; do
    MODULE_SRC_DIR="$(module_src_dir "$target")"
    select_modules_for_kernel "$target"

    if [ ! -d "$MODULE_SRC_DIR" ]; then
        err "Module directory not found for ${target}: ${MODULE_SRC_DIR}"
        MISSING=$((MISSING + 1))
        continue
    fi

    for entry in "${SELECTED_MODULES[@]}"; do
        file="${entry%%:*}"
        module_path="${MODULE_SRC_DIR}/${file}"
        if [ ! -f "$module_path" ]; then
            err "Missing for ${target}: ${module_path}"
            MISSING=$((MISSING + 1))
            continue
        fi

        if ! check_module_vermagic "$target" "$module_path"; then
            MISSING=$((MISSING + 1))
        fi
    done
done

if [ "$MISSING" -gt 0 ]; then
    err "${MISSING} module file(s) missing, aborting."
    exit 1
fi
ok "All module files found."

# ── Install modules ─────────────────────────────────────────────────
INSTALLED=0
for target in "${TARGET_KERNELS[@]}"; do
    MODULE_SRC_DIR="$(module_src_dir "$target")"
    BASE_DIR="/lib/modules/${target}/kernel"
    select_modules_for_kernel "$target"

    info "Installing modules for ${target} to ${BASE_DIR} ..."
    TARGET_INSTALLED=0
    for entry in "${SELECTED_MODULES[@]}"; do
        file="${entry%%:*}"
        rest="${entry#*:}"
        target_subdir="${rest#*:}"

        target_dir="${BASE_DIR}/${target_subdir}"
        mkdir -p "$target_dir"
        install -m 0644 "${MODULE_SRC_DIR}/${file}" "${target_dir}/${file}"
        TARGET_INSTALLED=$((TARGET_INSTALLED + 1))
        INSTALLED=$((INSTALLED + 1))
    done
    ok "Installed ${TARGET_INSTALLED} modules for ${target}."

    info "Updating module dependencies for ${target} (depmod)..."
    depmod -a "${target}"
    ok "Module dependencies updated for ${target}."
done

# ── Load modules ─────────────────────────────────────────────────────
info "Loading modules for the running kernel only (${KERNEL_VER})..."
select_load_order_for_kernel "$KERNEL_VER"

LOAD_OK=0
LOAD_FAIL=0
for module in "${LOAD_ORDER[@]}"; do
    modprobe -r "$module" 2>/dev/null || true
    if modprobe "$module" 2>/dev/null; then
        ok "  Loaded: ${module}"
        LOAD_OK=$((LOAD_OK + 1))
    else
        warn "  Failed to load: ${module} (may need reboot)"
        LOAD_FAIL=$((LOAD_FAIL + 1))
    fi
done

# ── Summary ──────────────────────────────────────────────────────────
echo ""
echo "============================================"
echo -e "${GREEN}  Installation complete!${NC}"
echo "============================================"
echo "  Running kernel:    ${KERNEL_VER}"
echo "  Installed kernels: ${TARGET_KERNELS[*]}"
echo "  Modules installed: ${INSTALLED}"
echo "  Modules loaded:    ${LOAD_OK} / $((LOAD_OK + LOAD_FAIL))"
if [ "$LOAD_FAIL" -gt 0 ]; then
    echo ""
    warn "Some modules failed to load. Please reboot and verify:"
    echo "    sudo reboot"
fi
echo ""
echo "  Verify with:"
echo "    lsmod | grep -E 'uvcvideo|hid_sensor|gs_usb|ch341'"
echo "============================================"
